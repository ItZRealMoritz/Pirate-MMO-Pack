#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform TintConfig {
    vec4 Tint;   // rgb = Farbfaktor, a = Stärke
    vec4 Sky;    // rgb = Himmelsfarbe, a = Deckkraft am Himmel
    vec4 Extra;  // x = Sättigung, y = Rot-Aufhellung, z = Vignette
};

layout(location = 0) out vec4 fragColor;

void main() {
    vec4 color = texture(InSampler, texCoord);
    float d = texture(DepthSampler, texCoord).r;
    vec3 c = color.rgb;
    float lum = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(lum), c, Extra.x);                 // etwas entsättigen
    vec3 tinted = c * Tint.rgb + vec3(Extra.y * lum, 0.0, 0.0);
    c = mix(c, tinted, Tint.a);
    if (d >= 0.99999) c = mix(c, Sky.rgb * (0.6 + lum), Sky.a);
    vec2 v = texCoord - 0.5;
    c *= 1.0 - Extra.z * dot(v, v) * 2.0;           // dunkle, rötliche Ränder
    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
