#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform FogConfig {
    vec4 FogColor;   // rgb = Nebelfarbe
    vec4 FogParams;  // x = Beginn (Blöcke), y = voll ab, z = maximale Deckkraft, w = Himmel-Deckkraft
    vec4 FogPlanes;  // x = near, y = far
};

layout(location = 0) out vec4 fragColor;

float linearDepth(float d) {
    float n = FogPlanes.x, f = FogPlanes.y;
#ifdef RENDERPEARL_DEPTH_IS_ZERO_TO_ONE
    return (n * f) / (f - d * (f - n));
#else
    float z = d * 2.0 - 1.0;
    return (2.0 * n * f) / (f + n - z * (f - n));
#endif
}

void main() {
    vec4 color = texture(InSampler, texCoord);
    float d = texture(DepthSampler, texCoord).r;
    float amount;
    if (d >= 0.99999) {
        amount = FogParams.w; // Himmel
    } else {
        float dist = linearDepth(d);
        amount = smoothstep(FogParams.x, FogParams.y, dist) * FogParams.z;
    }
    fragColor = vec4(mix(color.rgb, FogColor.rgb, amount), 1.0);
}
